"""
API endpoints initialization.
"""
