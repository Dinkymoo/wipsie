"""
Endpoints initialization.
"""
