# Clipboard History Manager

A browser extension for Microsoft Edge and Chrome that automatically saves the last 100 copied text items.

![Extension Icon](icons/icon128.png)

## Features

- 📋 **Automatic Capture** - Automatically saves text when you copy (Ctrl+C)
- 💾 **100 Item History** - Keeps the last 100 copied items
- 🔍 **Search** - Quickly find copied text with real-time search
- ⏰ **Timestamps** - See when each item was copied
- 🌐 **Source URLs** - Know where text was copied from
- 🗑️ **Delete Options** - Remove individual items or clear all
- 🔒 **Privacy First** - All data stored locally in your browser

## Quick Start

### Installation

1. Open Microsoft Edge or Chrome
2. Go to `edge://extensions/` (Edge) or `chrome://extensions/` (Chrome)
3. Enable "Developer mode"
4. Click "Load unpacked"
5. Select this folder
6. Start copying text!

See [INSTALLATION_MANUAL.md](INSTALLATION_MANUAL.md) for detailed step-by-step instructions.

## Usage

1. **Copy any text** on any webpage (Ctrl+C or right-click → Copy)
2. **Click the extension icon** to view your clipboard history
3. **Click any item** to copy it back to your clipboard
4. **Use search** to find specific text
5. **Delete items** individually or clear all

## Files

- `manifest.json` - Extension configuration
- `content.js` - Detects copy events on web pages
- `background.js` - Manages clipboard storage
- `popup.html/js/css` - User interface
- `icons/` - Extension icons

## Documentation

- [README.md](README.md) - This file
- [INSTALLATION.md](INSTALLATION.md) - Installation guide
- [INSTALLATION_MANUAL.md](INSTALLATION_MANUAL.md) - Detailed step-by-step guide
- [ARCHITECTURE.md](ARCHITECTURE.md) - Technical architecture
- [SUMMARY.md](SUMMARY.md) - Project summary

## Testing

Open [test-page.html](test-page.html) in your browser to test the extension with sample text.

## Privacy & Security

- ✅ All data stored locally in your browser
- ✅ No external servers - nothing leaves your computer
- ✅ No tracking or analytics
- ✅ Open source - review the code yourself

## Browser Compatibility

- ✅ Microsoft Edge (Chromium-based)
- ✅ Google Chrome
- ✅ Brave Browser
- ✅ Opera
- ✅ Other Chromium-based browsers

## Technical Details

- **Manifest Version**: 3
- **Permissions**: `storage`, `<all_urls>`
- **Storage**: Chrome Storage API (local)
- **Size**: ~100KB

## Development

To modify the extension:

1. Make your changes
2. Go to `edge://extensions/` or `chrome://extensions/`
3. Click the reload button on the extension card
4. Test your changes

## License

This extension is provided as-is for personal use.

## Version

1.0.0

---

**Happy copying! 📋✨**
