# Extension Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                      User's Browser                          │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌────────────────────┐         ┌──────────────────┐        │
│  │   Web Page         │         │  Extension Icon  │        │
│  │                    │         │  (Toolbar)       │        │
│  │  User selects text │         │                  │        │
│  │  and presses Ctrl+C│         │  Click to open → │        │
│  └────────┬───────────┘         └─────────┬────────┘        │
│           │                               │                  │
│           │ Copy Event                    │ Click Event      │
│           ▼                               ▼                  │
│  ┌─────────────────────────────────────────────────┐        │
│  │          Content Script (content.js)             │        │
│  │  • Listens for copy events                       │        │
│  │  • Captures selected text                        │        │
│  │  • Sends to background script                    │        │
│  └────────────────┬─────────────────────────────────┘        │
│                   │                                           │
│                   │ Message: {text, url, timestamp}           │
│                   ▼                                           │
│  ┌────────────────────────────────────────────────┐          │
│  │     Background Service Worker (background.js)  │          │
│  │  • Receives copy messages                      │          │
│  │  • Manages clipboard history storage           │          │
│  │  • Keeps max 100 items                         │          │
│  │  • Provides delete/clear API                   │          │
│  └────────┬──────────────────────┬─────────────────┘          │
│           │                      │                            │
│           │                      │ Read/Write                 │
│           │                      ▼                            │
│           │         ┌─────────────────────────┐              │
│           │         │   Chrome Storage API     │              │
│           │         │  (Local Storage)         │              │
│           │         │  • Stores history array  │              │
│           │         │  • Max 100 items         │              │
│           │         └─────────────────────────┘              │
│           │                                                   │
│           │ Get History Request                              │
│           ▼                                                   │
│  ┌────────────────────────────────────────────────┐          │
│  │           Popup UI (popup.html/js/css)         │          │
│  │                                                 │          │
│  │  ┌──────────────────────────────────────────┐ │          │
│  │  │  📋 Clipboard History      [Clear All]    │ │          │
│  │  ├──────────────────────────────────────────┤ │          │
│  │  │  🔍 Search clipboard history...          │ │          │
│  │  ├──────────────────────────────────────────┤ │          │
│  │  │  5 items                                 │ │          │
│  │  ├──────────────────────────────────────────┤ │          │
│  │  │  ⏰ 2 mins ago         [Copy] [Delete]   │ │          │
│  │  │  The quick brown fox...                  │ │          │
│  │  │  🌐 https://example.com                  │ │          │
│  │  ├──────────────────────────────────────────┤ │          │
│  │  │  ⏰ 5 mins ago         [Copy] [Delete]   │ │          │
│  │  │  function greet(name) {...               │ │          │
│  │  │  🌐 https://developer.mozilla.org        │ │          │
│  │  ├──────────────────────────────────────────┤ │          │
│  │  │  ... more items ...                      │ │          │
│  │  └──────────────────────────────────────────┘ │          │
│  │                                                 │          │
│  │  Features:                                      │          │
│  │  • Click item to copy                           │          │
│  │  • Search to filter                             │          │
│  │  • Delete individual items                      │          │
│  │  • Clear all with confirmation                  │          │
│  └─────────────────────────────────────────────────┘          │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## Data Flow

1. **Copy Event** → Content Script detects copy
2. **Message** → Content Script sends to Background Worker
3. **Storage** → Background Worker saves to Chrome Storage
4. **Display** → Popup reads from storage and shows history
5. **Interaction** → User clicks item to copy back to clipboard

## File Responsibilities

| File | Purpose | Lines of Code |
|------|---------|---------------|
| `manifest.json` | Extension configuration | 33 |
| `content.js` | Copy event detection | 15 |
| `background.js` | Storage management | 67 |
| `popup.html` | UI structure | 36 |
| `popup.js` | UI logic | 185 |
| `popup.css` | Styling | 231 |
| `icons/*` | Extension icons | 4 files |

## Key Features Implementation

### ✅ Last 100 Copies
- `MAX_HISTORY_SIZE = 100` constant in background.js
- Array slicing to maintain limit: `history.slice(0, MAX_HISTORY_SIZE)`

### ✅ Text Display
- Popup shows all items with text preview
- Search functionality to filter items
- Timestamps in human-readable format
- Source URL for each item

### ✅ Accessibility
- Click extension icon to open popup
- Click any item to copy it back
- Search box for quick filtering
- Delete buttons for cleanup

### ✅ Privacy
- All storage is local (Chrome Storage API)
- No external servers
- No data transmission
- User controls all data
